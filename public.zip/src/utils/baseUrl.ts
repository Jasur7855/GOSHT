export const baseUrl = "https://gosht.maksimovich.uz/api/";
