import styled from "styled-components";

export const SContainer = styled.div`
 padding:0 calc(3.4vw + 11.3px);
`;
